#include <stdio.h>
#include <time.h>
main() {

	int i,*p;
	time_t tt;
struct {
	unsigned char *a;
char b;
unsigned char *c;
int d;
}abc;
	int k=100;
	p=0;
	*p= (5) <<16;
	printf(" *p=%x \n",*p);
}
